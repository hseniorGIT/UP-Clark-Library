# About

## Development

Developed by [Giulio Menna](https://www.linkedin.com/in/giuliomenna) for [Leiden University Libraries](https://www.library.universiteitleiden.nl/).  

## Links

* [GitHub Repository](https://github.com/LeidenUniversityLibrary/Library-Search-Plugin-Public)
* [Leiden University's implementation](https://chrome.google.com/webstore/detail/leiden-search-assistant/dillijfbjhoiokfgjbngplcfggkkdnbn)

## Implementations by other libraries

* [Bond University Library](https://chrome.google.com/webstore/detail/library-search-plugin/eedkcdooojhfaadijkdliefkbdcihoae)
* [The University of Hong Kong Libraries](https://chrome.google.com/webstore/detail/hkul-search-assistant/lfjmkaiddobaebgokockcncpchpbnoad)
* [Ulstein bibliotek](https://github.com/hjorung/Finn-litteratur-i-biblioteket)
